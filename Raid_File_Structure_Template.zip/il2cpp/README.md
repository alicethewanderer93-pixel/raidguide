IL2CPP notes
